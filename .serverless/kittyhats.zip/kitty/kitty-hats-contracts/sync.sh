#!/bin/bash
cp ../../../contracts/build/contracts/* ./
