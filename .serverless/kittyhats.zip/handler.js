"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var getKittyStickers_1 = require("./kitty/getKittyStickers");
var invalidateKittyId_1 = require("./kitty/invalidateKittyId");
module.exports.getKittyStickers = getKittyStickers_1.default;
module.exports.invalidateKittyId = invalidateKittyId_1.default;
//# sourceMappingURL=handler.js.map